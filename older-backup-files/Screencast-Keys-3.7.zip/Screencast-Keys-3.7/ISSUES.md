# Bug Report / Feature Request / Disscussions

If you want to report problem or request feature, please make issues.

https://github.com/nutti/Screencast-Keys/issues

You can discuss Screencast Keys at other places.
See the link below for further details.

* [Blender Wiki page](http://wiki.blender.org/index.php/Extensions:2.6/Py/Scripts/3D_interaction/Screencast_Key_Status_Tool)
* [Blender Artist](https://blenderartists.org/t/screencast-keys-status-tool/472469)
